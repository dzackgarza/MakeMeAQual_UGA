---
title: UGA Real Analysis Qualifying Exam Questions
---

!include sections/2019 Fall.md

!include sections/2019 Spring.md

!include sections/2018 Fall.md

!include sections/2018 Spring.md

!include sections/2017 Fall.md

!include sections/2017 Spring.md

!include sections/2016 Fall.md

!include sections/2016 Spring.md

!include sections/2015 Fall.md

!include sections/2015 Spring.md

!include sections/2014 Fall.md

!include sections/2014 Spring.md

